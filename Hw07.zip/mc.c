/**
 * mc.c
 * CIS240 Fall 2016
 */

#include "lc4libc.h"

/************************************************
 *  DATA STRUCTURES FOR GAME STATE
 ***********************************************/

/** Width and height of lc4 */
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 124

/** Number of cities and launchers in the game */
#define NUM_CITIES 2

/** Number of targets incoming can target (cities + 1 launcher) */
#define NUM_TARGETS NUM_CITIES+1 

/** Number of maximum outgoing and incoming allowed on the screen */
#define MAX_OUTGOING 1
#define MAX_INCOMING 3

/** Number of missiles allowed per round*/
#define MISSILES_PER_ROUND 8

/** The y position of where the cities and launcher are located */
#define GROUND_LEVEL 116

/** The x positions of where the cities and launcher are located */
#define LEFT_CITY_XPOS	20
#define RIGHT_CITY_XPOS 100
#define MISSILE_COMMAND_XPOS 60

/** The squared distance where missiles will contact
 * if it is in the radius */
#define CONTACT_RADIUS 250

/** Delay between GETC_TIMER - default at 10ms */
#define GETC_TIMER_DELAY 10

/** 2D array presenting the cursor */
lc4uint cursorImage[] = {
  0x00,
  0x00,
  0x18,
  0x3C,
  0x3C,
  0x18,
  0x00,
  0x00
};

/** 2D array presenting the launcherImage */
lc4uint launcherImage[] = {
  0x18,
  0x18,
  0x18,
  0x18,
  0x18,
  0x3C,
  0x3C,
  0x24
};

lc4uint cityImage[] = {
  0x08,
  0x08,
  0x18,
  0x18,
  0x3C,
  0x3C,
  0x7E,
  0x7E
};

/** Array of targets that the incoming will target */
lc4uint targets[NUM_TARGETS];

/** City struct that consists of the x position and 2D array */
/** representing the city's image */
typedef struct {
  lc4bool isDestroyed;
  lc4uint x;
  lc4uint cityImage[8];
}City;

/** Array consisting of cities */
City cities[NUM_CITIES];

/** Missile launcher struct that consists of the number missiles */
/** that the launcher has left, its x position and 2D array */
/** representing the missile launcher's image */
typedef struct {
  lc4bool isDestroyed;
  int missilesLeft;
  int x;
  lc4uint launcherImage[8];
}MissileLauncher;

/** Instance of the MissileLauncher Struct */
MissileLauncher missileLauncher;

/************************************************
 *  Projectile Struct
 *  lc4bool isActive - boolean representing 
 *                     if the projectile 
 *                     is active or not
 *  x0 - keeps track of its x starting position
 *  y0 - keeps track of its y starting position
 *  xnext - keeps track of its next x position
 *  ynext - keeps track of its next y position
 *  xend - keeps track of its ending x position
 *  yend - keeps track of its x ending position
 *  offset - keeps track of offset in the processNextPosition function
 ***********************************************/
typedef struct {
  lc4bool isActive;
  int x0;
  int y0;
  int xnext;
  int ynext;
  int xend;
  int yend;
  int offset;
}Projectile;

/** Array consisting of missiles on the screen */
Projectile outgoing[MAX_OUTGOING];

/** Array consisting of incoming on the screen */
Projectile incoming[MAX_INCOMING];

/** Cursor struct consisting of the cursor's x and y position */
typedef struct{
  int x;
  int y;
}Cursor;

/** Instance of the cursor*/
Cursor cursor;

/***************************************************************
 * Debugging and utility functions
 * DO NOT EDIT
 ***************************************************************/

/************************************************
 *  Printnum - Prints out the value on the lc4
 ***********************************************/
void printnum (int n) {
  int abs_n;
  char str[10], *ptr;

  // Corner case (n == 0)
  if (n == 0) {
    lc4_puts ((lc4uint*)"0");
    return;
  }
 
  abs_n = (n < 0) ? -n : n;

  // Corner case (n == -32768) no corresponding +ve value
  if (abs_n < 0) {
    lc4_puts ((lc4uint*)"-32768");
    return;
  }

  ptr = str + 10; // beyond last character in string

  *(--ptr) = 0; // null termination

  while (abs_n) {
    *(--ptr) = (abs_n % 10) + 48; // generate ascii code for digit
    abs_n /= 10;
  }

  // Handle -ve numbers by adding - sign
  if (n < 0) *(--ptr) = '-';

  lc4_puts((lc4uint*)ptr);
}

void endl () {
  lc4_puts((lc4uint*)"\n");
}

/************************************************
 *  abs - returns the absolute value
 ***********************************************/
int abs(int value)
{
  if(value < 0)
    return -value;
  return value;
}

/************************************************
 *  rand16 - This function returns a random 
 *  number between 0 and 128
 ***********************************************/
int rand16 ()
{
  int lfsr;

  // Advance the lfsr seven times
  lfsr = lc4_lfsr();
  lfsr = lc4_lfsr();
  lfsr = lc4_lfsr();
  lfsr = lc4_lfsr();
  lfsr = lc4_lfsr();
  lfsr = lc4_lfsr();
  lfsr = lc4_lfsr();

  // return the last 7 bits
  return (lfsr & 0x7F);
}

/***************************************************************
 * End of Debugging and utility functions
 ***************************************************************/

/************************************************
 * DrawCursor - 
 * Draws the cursor sprite in white 
 ***********************************************/
 void DrawCursor() 
 {
  lc4_draw_sprite(cursor.x, cursor.y, WHITE, cursorImage);
 }

/************************************************
 *  DrawMissileLauncher - 
 *  Draws the missile launcher in white based on 
 *  the number of missiles left
 ***********************************************/
 void DrawMissileLauncher()
 {
  // checks if the missile launcher is destroyed
  if(missileLauncher.isDestroyed == 0) { 
    int i, y_even, y_odd;
    y_even = 0;
    y_odd = 0;
    // loops and draws the number of missiles that are left
    for(i = 0; i < missileLauncher.missilesLeft; i++) {
      if(i % 2 == 0) { // checks if the missile to be drawn is on the left or right side
        lc4_draw_sprite(MISSILE_COMMAND_XPOS - 5, GROUND_LEVEL + y_even, WHITE, missileLauncher.launcherImage); // draws missiles on the left side of the launcher
        y_even -= 5; // decrements so the missiles are drawn on top of each other
      }
      else {
        lc4_draw_sprite(MISSILE_COMMAND_XPOS + 5, GROUND_LEVEL + y_odd, WHITE, missileLauncher.launcherImage);  // draws missiles on the right side of the launcher
        y_odd -= 5; // decrements so the missiles are drawn on top of each other
      }
    }
  }
 }

/************************************************
 *  DrawCities - 
 *  Draws the cities in white
 ***********************************************/
 void DrawCities()
 {
  // checks if the left city is destroyed
  if(cities[0].isDestroyed == 0) {
    lc4_draw_sprite(LEFT_CITY_XPOS, GROUND_LEVEL, WHITE, cities[0].cityImage);
  }
  // checks if the right city is destroyed
  if(cities[1].isDestroyed == 0) {
    lc4_draw_sprite(RIGHT_CITY_XPOS, GROUND_LEVEL, WHITE, cities[1].cityImage);
  }
 }

/************************************************
 *  DrawIncoming - 
 *  Draws each incoming 
 ***********************************************/
 void DrawIncoming()
 {
  int i;
  for(i = 0; i < MAX_INCOMING; i++) {
    if(incoming[i].isActive == 0) {
      lc4_draw_line(incoming[i].x0, incoming[i].y0, incoming[i].x0, incoming[i].y0, RED);
      incoming[i].isActive = 1;
    }
    else {
      lc4_draw_line(incoming[i].x0, incoming[i].y0, incoming[i].xnext, incoming[i].ynext, RED);
      if(incoming[i].xnext == incoming[i].xend && incoming[i].ynext == incoming[i].yend) {
        incoming[i].isActive = 0;
        incoming[i].offset = 0;
      }
    }
  }
 }

/************************************************
 *  DrawOutgoing
 *  Draws each outgoing missile 
 ***********************************************/
 void DrawOutgoing()
 {
  int i;
  for(i = 0; i < MAX_OUTGOING; i++) {
    if(outgoing[i].isActive == 1) {
       lc4_draw_line(outgoing[i].x0, outgoing[i].y0, outgoing[i].xnext, outgoing[i].ynext, GREEN);
       if(outgoing[i].xnext == outgoing[i].xend && outgoing[i].ynext == outgoing[i].yend) {
        outgoing[i].isActive = 0;
        outgoing[i].offset = 0;
       }
    }
  }
 }

 void processNextPosition(Projectile* p) 
 {
    int x0, x1, y0, y1, st, deltax, deltay, error, y, ystep, x, updateOffSet;
    x0 = p->x0;
    y0 = p->y0;
    x1 = p->xend;
    y1 = p->yend;

    //xstart = 60
    //ystart = 116
    //xend = 70
    //yend = 100

    if(abs(y1 - y0) > abs(x1 - x0)) {
      st = 1;
    }
    else {
      st = 0;
    }

    if(st == 1) {
      // swap(x0, y0)
      x0 = x0 - y0;
      y0 = x0 + y0;
      x0 = y0 - x0;

      // swap(x1, y1)
      x1 = x1 - y1;
      y1 = x1 + y1;
      x1 = y1 - x1;
    }

    if(x0 > x1) {
      // swap(x0, x1)
      x0 = x0 - x1;
      x1 = x0 + x1;
      x0 = x1 - x0;

      // swap(y0, y1)
      y0 = y0 - y1;
      y1 = y0 + y1;
      y0 = y1 - y0;
    }

    deltax = x1 - x0;
    deltay = abs(y1 - y0);
    error = 0;
    y = y0;

    if(y0 < y1) {
      ystep = 1;
    }
    else {
      ystep = -1;
    }

    updateOffSet = 0;

    for(x = x0; x <= x1; x++) {
      if(updateOffSet == 0) {
       if(st == 1 && x == x0 + p->offset) {
        p->xnext = y;
        p->ynext = x;
        p->offset += 1;
        updateOffSet = 1;
       }
       else if(st == 0 && x == x0 + p->offset) {
        p->xnext = x;
        p->ynext = y;
        p->offset += 1;
        updateOffSet = 1;
       }
      }

      error = error + deltay;

      if(2 * error >= deltax) {
        y = y + ystep;
        error = error - deltax;
      }
    }
 }

/************************************************
 *  Redraw - 
 *  Assuming that the PennSim is run with double 
 *  buffered mode, (using the launcher -> 
 *  (java -jar PennSim.jar -d))
 *  First, we should clear the video memory buffer 
 *  using lc4_reset_vmem.  Then we draw the scene 
 *  and then swap the video memory buffer using 
 *  lc4_blt_vmem
 ***********************************************/
void Redraw()
{
  lc4_reset_vmem();

  DrawCursor();
  DrawMissileLauncher();
  DrawCities();
  DrawOutgoing();
  DrawIncoming();
  lc4_blt_vmem();
}

/************************************************
 *  Reset - 
 *  Clears the screen
 ***********************************************/
void reset()
{
  lc4_reset_vmem();
  lc4_blt_vmem();
}

/************************************************
 *  ResetGame - 
 *  Resets the game. 
 ***********************************************/

 void ResetGame()
 {
  int i, j, k;    

  cursor.x = 70;
  cursor.y = 100;
  drawCursor();

  missileLauncher.missilesLeft = 8; // reset the missile launcher to have 8 missiles
  missileLauncher.isDestroyed = 0;  // missile launcher is not destroyed
  missileLauncher.launcherImage[0] = 0x18;
  missileLauncher.launcherImage[1] = 0x18;
  missileLauncher.launcherImage[2] = 0x18;
  missileLauncher.launcherImage[3] = 0x18;
  missileLauncher.launcherImage[4] = 0x18;
  missileLauncher.launcherImage[5] = 0x3C;
  missileLauncher.launcherImage[6] = 0x3C;
  missileLauncher.launcherImage[7] = 0x24;
  DrawMissileLauncher();

  cities[0].isDestroyed = 0;
  cities[0].x = LEFT_CITY_XPOS;
  cities[0].cityImage[0] = 0x08;
  cities[0].cityImage[1] = 0x08;
  cities[0].cityImage[2] = 0x18;
  cities[0].cityImage[3] = 0x18;
  cities[0].cityImage[4] = 0x3C;
  cities[0].cityImage[5] = 0x3C;
  cities[0].cityImage[6] = 0x7E;
  cities[0].cityImage[7] = 0x7E;

  cities[1].isDestroyed = 0;
  cities[1].x = RIGHT_CITY_XPOS;
  cities[1].cityImage[0] = 0x08;
  cities[1].cityImage[1] = 0x08;
  cities[1].cityImage[2] = 0x18;
  cities[1].cityImage[3] = 0x18;
  cities[1].cityImage[4] = 0x3C;
  cities[1].cityImage[5] = 0x3C;
  cities[1].cityImage[6] = 0x7E;
  cities[1].cityImage[7] = 0x7E;
  drawCities();

  for(k = 0; k < MAX_OUTGOING; k++) {
    outgoing[k].x0 = MISSILE_COMMAND_XPOS;
    outgoing[k].y0 = GROUND_LEVEL;
    outgoing[k].xnext = MISSILE_COMMAND_XPOS;
    outgoing[k].ynext = GROUND_LEVEL;
    outgoing[k].xend = cursor.x;
    outgoing[k].yend = cursor.y;
    outgoing[k].isActive = 0;
  }
  drawOutgoing();

  for(i = 0; i < MAX_INCOMING; i++) {
    j = rand16();
    incoming[i].x0 = j;
    incoming[i].y0 = 0;
    incoming[i].xnext = j;
    incoming[i].ynext = 0;
    incoming[i].xend = GROUND_LEVEL;
    incoming[i].yend = 100;
    incoming[i].isActive = 0;
  }
  drawIncoming(); 

  //lc4_blt_vmem();
 }

/************************************************
 *  main - 
 *  Initalize game state by reseting the game state
 *  Loops until the the user loses
 ***********************************************/
 int main ()
 {
  //** Print to screen and initalize game state. */
  lc4_puts ((lc4uint*)"Welcome to Missile Command!\n");
  lc4_puts ((lc4uint*)"Press r to shoot a missile.\n");
  lc4_puts ((lc4uint*)"Press w, a, s and d to move the cursor.\n");

  ResetGame();

  while(1) 
  {
    int input;
    int i, j;

    input = lc4_getc_timer(0x1F4);
    if(input == 0x77) { // if 'w' is pressed
      cursor.y -= 10;
    }
    else if(input == 0x61) { // if 'a' is pressed
      cursor.x -= 10;
    }
    else if(input == 0x73) { // if 's' is pressed
      cursor.y += 10;
    }
    else if(input == 0x64) { // if 'd' is pressed
      cursor.x += 10;
    }
    else if(input == 0x72) { // if 'r' is pressed
      if(outgoing[0].isActive == 0) {
        outgoing[0].isActive = 1;
        outgoing[0].xend = cursor.x;
        outgoing[0].yend = cursor.y; 
        missileLauncher.missilesLeft--;
      }
    }

    Redraw();

    /**for(i = 0; i < MAX_INCOMING; i++) {
      if(incoming[i].isActive == 1) {
        processNextPosition(&incoming[i]);
      }
    }**/
    for(j = 0; j < MAX_OUTGOING; j++) {
      if(outgoing[j].isActive == 1) {
        processNextPosition(&outgoing[j]);
      }
    }
  }
  return 0;
}
